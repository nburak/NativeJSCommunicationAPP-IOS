import Foundation
import SQLite

class DbTool
{
    static var sharedInstance=DbTool()
    var db2:Connection?
    
    let Users = Table("Users")
    let Id = Expression<Int64>("Id")
    let Username = Expression<String>("Username")
    let Password = Expression<String>("Password")
     
    
    init()
    {
        var path=NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first!
        print(path)
        
        do
        {
            db2 = try Connection("\(path)/Users.sqlite3")
            
            
            
            try db2!.run(Users.create(temporary: false, ifNotExists: true, block:{
                
                t in
                t.column(Id, primaryKey: true)
                t.column(Username)
                t.column(Password)
                
                
                
            }))
            
            
            
            
        }
        catch
        {
            print("Hata \(error)")
        }
    }
    
    func gbd()
    {
        
    }
    
    func addEntranet(username:String,password:String)
    {
        do
        {
            try db2!.run(Users.insert(Username<-username,Password<-password))
        }
        catch
        {
            
        }
    }
    
 
    
   
    
    
    func isExist(username:String, password:String) -> Bool
    {
        var isExist=false
        do
        {
            let result = try db2!.prepare("Select * from Users where Username='"+username+"'")
            
            for row in result
            {
                isExist=true
            }
        }
        catch
        {
            
        }
        
        return isExist
    }
}

